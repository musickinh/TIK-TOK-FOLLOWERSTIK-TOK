$('.check').click(function() {
	var active_code = $('#activate-code').val();
	if (active_code == '4361'){
    $('#myModal11').modal('show');
	}else{
	$('#myModal10').modal('show');
}}); 